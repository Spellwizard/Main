package net.obviam.droids.controller;

import net.obviam.droids.model.Arena;
import net.obviam.droids.model.Droid;
import java.util.List;
import net.obviam.droids.model.Enemy;
public class ArenaController {

    private static final int unit = 32;
    private Arena arena;

    /**
     * the target cell *
     */
    private float targetX, targetY;
    /**
     * true if the droid moves *
     */
    private boolean moving = false;

    public ArenaController(Arena arena) {
        this.arena = arena;
    }

    public void update(float delta) {
        Droid droid = arena.getDroid();
        if (moving) {

            // ***************************************************
            // determine droid rotation (aim toward target)
            double rot = Math.atan2(
                    targetX - droid.getX(),
                    droid.getY() - targetY) * 180.0 / Math.PI;
            droid.setRotation((float) rot);
            System.out.println("Droid Rotation: " + rot);

            // ***************************************************


            // move on X
            int bearing = 1;
            if (droid.getX() > targetX) {
                bearing = -1;
            }
            if (droid.getX() != targetX) {
                droid.setX(droid.getX() + bearing * droid.getSpeed() * delta);
                // check if arrived
                if ((droid.getX() < targetX && bearing == -1)
                        || (droid.getX() > targetX && bearing == 1)) {
                    droid.setX(targetX);
                }
            }
            // move on Y
            bearing = 1;
            if (droid.getY() > targetY) {
                bearing = -1;
            }
            //Sets the speed and direction of the x and y independtly alllowing
            //dual direction movement however not as fluid as it could be
            if (droid.getY() != targetY) {
                droid.setY(droid.getY() + bearing * droid.getSpeed() * delta);
                // check if arrived
                if ((droid.getY() < targetY && bearing == -1)
                        || (droid.getY() > targetY && bearing == 1)) {
                    droid.setY(targetY);
                }
            }
            //make sure that the droid is not sharing the same position as the enemies
            System.out.println("\nHI");//<- Why is this not running?
            for(Enemy alpha: arena.getEnemies()){
                if(alpha.getX() ==  droid.getX()
                        &&alpha.getY()  ==  droid.getY()){
                    droid.setSpeed(0);
                    System.out.println("IT WORKED");
                }
            }

            // check if arrived
            //compare the current position of the droid to the desired code
            //a statement should go here to prevent looping when encountering objects
            if (droid.getX() == targetX && droid.getY() == targetY) {
                moving = false;
            }
            //
        }
    }

    // * Input events ----------
    /**
     * triggered with the coordinates every click *
     */
    public boolean onClick(int x, int y) {
        //divide the x and y to a assingable grid
        targetX = x / unit;
        targetY = y / unit;
        //an if statement to prevent a movement to / past an obsticale might go here

        //this is insures that the little guy does not exceed the entire intial page design
        if (arena.getGrid()[(int) targetY][(int) targetX] == null) {
            // start moving the droid towards the target
            moving = true;
            return true;
        }
        //if not then return false to prevent movement
        return false;
    }
}
