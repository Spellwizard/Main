package net.obviam.droids.view;

import java.awt.Graphics;

public interface Renderer {
	public void render(Graphics g);
}
